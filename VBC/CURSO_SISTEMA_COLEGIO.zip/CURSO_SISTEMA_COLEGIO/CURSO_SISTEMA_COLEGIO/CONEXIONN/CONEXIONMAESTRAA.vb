﻿Imports System.Data.SqlClient
Imports System.Configuration
Module CONEXIONMAESTRAA
    Public conexion As New SqlConnection("Data Source=PC01\SQLEXPRESS;Initial Catalog=BASECOLEGIO;Integrated Security=True")
    Sub abrir()
        If conexion.State = 0 Then
            conexion.Open()
        End If
    End Sub
    Sub Cerrar()
        If conexion.State = 1 Then
            conexion.Close()
        End If
    End Sub

End Module
