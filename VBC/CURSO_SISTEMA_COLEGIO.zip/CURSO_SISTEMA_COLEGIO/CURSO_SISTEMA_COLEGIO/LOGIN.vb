﻿Public Class LOGIN
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Close()

    End Sub

    Private Sub TextBox1_Click(sender As Object, e As EventArgs) Handles txtlogin.Click
        txtlogin.Text = ""
        txtlogin.Focus()

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtlogin.TextChanged

    End Sub

    Private Sub txtpaswor_Click(sender As Object, e As EventArgs) Handles txtpaswor.Click
        txtpaswor.Text = ""
        txtpaswor.Focus()
    End Sub

    Private Sub txtpaswor_TextChanged(sender As Object, e As EventArgs) Handles txtpaswor.TextChanged

    End Sub
End Class
